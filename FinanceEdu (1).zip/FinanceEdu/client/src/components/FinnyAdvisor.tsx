import { Sparkles, TrendingUp, TrendingDown, AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import type { FinnyAdvice } from '@shared/schema';

interface FinnyAdvisorProps {
  advice: FinnyAdvice[];
  compact?: boolean;
}

export function FinnyAdvisor({ advice, compact = false }: FinnyAdvisorProps) {
  const { t } = useLanguage();

  const typeIcons = {
    warning: AlertCircle,
    success: CheckCircle2,
    tip: TrendingUp,
    info: Info,
  };

  const typeColors = {
    warning: 'text-yellow-600 dark:text-yellow-400 bg-yellow-500/10',
    success: 'text-green-600 dark:text-green-400 bg-green-500/10',
    tip: 'text-blue-600 dark:text-blue-400 bg-blue-500/10',
    info: 'text-primary bg-primary/10',
  };

  if (compact) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            {t.dashboard.finnyAdvice}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {advice.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t.finny.intro}</p>
          ) : (
            advice.slice(0, 2).map((item) => {
              const Icon = typeIcons[item.type];
              return (
                <div
                  key={item.id}
                  className={`flex items-start gap-2 p-2 rounded-lg ${typeColors[item.type]}`}
                  data-testid={`finny-advice-${item.id}`}
                >
                  <Icon className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <p className="text-sm">{item.message}</p>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg">
            <Sparkles className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <CardTitle className="text-lg">{t.finny.greeting}</CardTitle>
            <p className="text-sm text-muted-foreground">{t.finny.intro}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 space-y-3">
        {advice.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted-foreground">{t.finny.intro}</p>
          </div>
        ) : (
          advice.map((item) => {
            const Icon = typeIcons[item.type];
            return (
              <div
                key={item.id}
                className={`flex items-start gap-3 p-3 rounded-lg ${typeColors[item.type]} transition-all duration-200`}
                data-testid={`finny-advice-${item.id}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${typeColors[item.type]}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">{item.message}</p>
                  {item.category && (
                    <Badge variant="outline" className="mt-2 text-xs">
                      {item.category}
                    </Badge>
                  )}
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
