import { useState } from 'react';
import { Target, Plus, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import type { Goal } from '@shared/schema';

interface GoalCardProps {
  goal: Goal;
  onAddSavings: (goalId: string, amount: number) => Promise<void>;
  onDelete: (goalId: string) => Promise<void>;
  compact?: boolean;
}

export function GoalCard({ goal, onAddSavings, onDelete, compact = false }: GoalCardProps) {
  const { t } = useLanguage();
  const [amount, setAmount] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const progress = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
  const isCompleted = goal.currentAmount >= goal.targetAmount;
  const remaining = Math.max(goal.targetAmount - goal.currentAmount, 0);

  const handleAddSavings = async () => {
    const value = parseFloat(amount);
    if (isNaN(value) || value <= 0) return;
    
    setIsLoading(true);
    try {
      await onAddSavings(goal.id, value);
      setAmount('');
      setIsOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  if (compact) {
    return (
      <div 
        className="p-3 rounded-lg bg-muted/50 space-y-2"
        data-testid={`goal-card-${goal.id}`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${isCompleted ? 'bg-green-500' : 'bg-primary'}`}>
              {isCompleted ? (
                <Check className="w-3 h-3 text-white" />
              ) : (
                <Target className="w-3 h-3 text-primary-foreground" />
              )}
            </div>
            <span className="font-medium text-sm truncate">{goal.title}</span>
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {goal.currentAmount.toFixed(0)} / {goal.targetAmount.toFixed(0)} AZN
          </span>
        </div>
        <Progress value={progress} className="h-1.5" />
      </div>
    );
  }

  return (
    <Card data-testid={`goal-card-${goal.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isCompleted ? 'bg-green-500' : 'bg-gradient-to-br from-primary to-accent'}`}>
              {isCompleted ? (
                <Check className="w-5 h-5 text-white" />
              ) : (
                <Target className="w-5 h-5 text-primary-foreground" />
              )}
            </div>
            <div className="min-w-0">
              <CardTitle className="text-base truncate">{goal.title}</CardTitle>
              <p className="text-sm text-muted-foreground">
                {isCompleted ? t.goals.completed : `${t.goals.remaining}: ${remaining.toFixed(2)} AZN`}
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive hover:text-destructive"
            onClick={() => onDelete(goal.id)}
            data-testid={`button-delete-goal-${goal.id}`}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">{t.goals.progress}</span>
            <span className="font-medium">{progress.toFixed(0)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between text-sm">
            <span>{goal.currentAmount.toFixed(2)} AZN</span>
            <span className="text-muted-foreground">{goal.targetAmount.toFixed(2)} AZN</span>
          </div>
        </div>

        {!isCompleted && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full" data-testid={`button-add-savings-${goal.id}`}>
                <Plus className="mr-2 h-4 w-4" />
                {t.goals.addSavings}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>{t.goals.addSavings}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder={`${t.transactions.amount} (AZN)`}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  data-testid="input-savings-amount"
                />
                <div className="flex gap-2 justify-end">
                  <Button
                    variant="outline"
                    onClick={() => setIsOpen(false)}
                    data-testid="button-cancel-savings"
                  >
                    {t.transactions.cancel}
                  </Button>
                  <Button
                    onClick={handleAddSavings}
                    disabled={isLoading || !amount}
                    data-testid="button-confirm-savings"
                  >
                    {t.transactions.save}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
}
