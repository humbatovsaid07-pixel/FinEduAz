import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { CalendarIcon, Loader2, Plus, Minus } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useLanguage } from '@/contexts/LanguageContext';
import { transactionCategories, type Transaction } from '@shared/schema';
import { cn } from '@/lib/utils';

const transactionFormSchema = z.object({
  date: z.date(),
  category: z.enum(transactionCategories),
  amount: z.coerce.number().positive('Amount must be positive'),
  type: z.enum(['income', 'outcome']),
  description: z.string().optional(),
});

type TransactionFormData = z.infer<typeof transactionFormSchema>;

interface TransactionFormProps {
  onSubmit: (data: TransactionFormData) => Promise<void>;
  initialData?: Transaction;
  trigger?: React.ReactNode;
  defaultType?: 'income' | 'outcome';
}

export function TransactionForm({ onSubmit, initialData, trigger, defaultType = 'outcome' }: TransactionFormProps) {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<TransactionFormData>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      date: initialData ? new Date(initialData.date) : new Date(),
      category: initialData?.category || 'other',
      amount: initialData?.amount || 0,
      type: initialData?.type || defaultType,
      description: initialData?.description || '',
    },
  });

  const handleSubmit = async (data: TransactionFormData) => {
    setIsLoading(true);
    try {
      await onSubmit(data);
      setOpen(false);
      form.reset();
    } finally {
      setIsLoading(false);
    }
  };

  const categoryLabels: Record<string, string> = {
    food: t.transactions.categories.food,
    transport: t.transactions.categories.transport,
    entertainment: t.transactions.categories.entertainment,
    education: t.transactions.categories.education,
    health: t.transactions.categories.health,
    shopping: t.transactions.categories.shopping,
    utilities: t.transactions.categories.utilities,
    other: t.transactions.categories.other,
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button data-testid="button-add-transaction">
            <Plus className="mr-2 h-4 w-4" />
            {t.transactions.add}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {initialData ? t.transactions.edit : t.transactions.add}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="flex gap-2">
              <Button
                type="button"
                variant={form.watch('type') === 'income' ? 'default' : 'outline'}
                className={cn(
                  'flex-1',
                  form.watch('type') === 'income' && 'bg-green-600 hover:bg-green-700'
                )}
                onClick={() => form.setValue('type', 'income')}
                data-testid="button-type-income"
              >
                <Plus className="mr-2 h-4 w-4" />
                {t.transactions.income}
              </Button>
              <Button
                type="button"
                variant={form.watch('type') === 'outcome' ? 'default' : 'outline'}
                className={cn(
                  'flex-1',
                  form.watch('type') === 'outcome' && 'bg-red-600 hover:bg-red-700'
                )}
                onClick={() => form.setValue('type', 'outcome')}
                data-testid="button-type-outcome"
              >
                <Minus className="mr-2 h-4 w-4" />
                {t.transactions.outcome}
              </Button>
            </div>

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>{t.transactions.date}</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            'w-full pl-3 text-left font-normal',
                            !field.value && 'text-muted-foreground'
                          )}
                          data-testid="button-date-picker"
                        >
                          {field.value ? (
                            format(field.value, 'PPP')
                          ) : (
                            <span>{t.transactions.date}</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date > new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.transactions.category}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-category">
                        <SelectValue placeholder={t.transactions.category} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {transactionCategories.map((category) => (
                        <SelectItem key={category} value={category} data-testid={`option-category-${category}`}>
                          {categoryLabels[category]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.transactions.amount} (AZN)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      {...field}
                      data-testid="input-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.transactions.description}</FormLabel>
                  <FormControl>
                    <Input
                      placeholder={t.transactions.description}
                      {...field}
                      data-testid="input-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-2 justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                data-testid="button-cancel"
              >
                {t.transactions.cancel}
              </Button>
              <Button type="submit" disabled={isLoading} data-testid="button-save">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t.common.loading}
                  </>
                ) : (
                  t.transactions.save
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
