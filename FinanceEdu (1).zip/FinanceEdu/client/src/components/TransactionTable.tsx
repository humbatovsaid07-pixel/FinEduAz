import { format } from 'date-fns';
import { Pencil, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/contexts/LanguageContext';
import { TransactionForm } from './TransactionForm';
import type { Transaction } from '@shared/schema';

interface TransactionTableProps {
  transactions: Transaction[];
  onEdit: (id: string, data: Partial<Transaction>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  isLoading?: boolean;
}

export function TransactionTable({ transactions, onEdit, onDelete, isLoading }: TransactionTableProps) {
  const { t } = useLanguage();

  const categoryLabels: Record<string, string> = {
    food: t.transactions.categories.food,
    transport: t.transactions.categories.transport,
    entertainment: t.transactions.categories.entertainment,
    education: t.transactions.categories.education,
    health: t.transactions.categories.health,
    shopping: t.transactions.categories.shopping,
    utilities: t.transactions.categories.utilities,
    other: t.transactions.categories.other,
  };

  const categoryColors: Record<string, string> = {
    food: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
    transport: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
    entertainment: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
    education: 'bg-green-500/10 text-green-600 dark:text-green-400',
    health: 'bg-red-500/10 text-red-600 dark:text-red-400',
    shopping: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
    utilities: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400',
    other: 'bg-gray-500/10 text-gray-600 dark:text-gray-400',
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{t.dashboard.transactions}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-pulse text-muted-foreground">{t.common.loading}</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{t.dashboard.transactions}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <TrendingUp className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">{t.dashboard.noTransactions}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
        <CardTitle>{t.dashboard.transactions}</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">{t.transactions.date}</TableHead>
                <TableHead>{t.transactions.category}</TableHead>
                <TableHead className="text-right">{t.transactions.amount}</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((transaction) => (
                <TableRow key={transaction.id} data-testid={`row-transaction-${transaction.id}`}>
                  <TableCell className="font-medium text-sm">
                    {format(new Date(transaction.date), 'dd/MM/yy')}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="secondary" 
                      className={`${categoryColors[transaction.category]} border-0`}
                    >
                      {categoryLabels[transaction.category]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      {transaction.type === 'income' ? (
                        <TrendingUp className="w-4 h-4 text-green-500" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-500" />
                      )}
                      <span className={transaction.type === 'income' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                        {transaction.type === 'income' ? '+' : '-'}{transaction.amount.toFixed(2)} AZN
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <TransactionForm
                        initialData={transaction}
                        onSubmit={async (data) => {
                          await onEdit(transaction.id, {
                            ...data,
                            date: data.date.toISOString(),
                          });
                        }}
                        trigger={
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            data-testid={`button-edit-${transaction.id}`}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        }
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => onDelete(transaction.id)}
                        data-testid={`button-delete-${transaction.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
