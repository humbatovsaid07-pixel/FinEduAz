import { Link, useLocation } from 'wouter';
import { Moon, Sun, Globe, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { languageNames, type Language } from '@/lib/i18n';

export function Header() {
  const { language, setLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isLanding = location === '/';

  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className={`sticky top-0 z-50 w-full transition-all duration-300 ${
      isLanding 
        ? 'bg-transparent' 
        : 'bg-background/80 backdrop-blur-md border-b border-border'
    }`}>
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <Link href="/">
          <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent-foreground bg-clip-text text-transparent cursor-pointer" data-testid="link-logo">
            {t.app.name}
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-2">
          {user && (
            <>
              <Link href="/dashboard">
                <Button 
                  variant={location === '/dashboard' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-dashboard"
                >
                  {t.nav.dashboard}
                </Button>
              </Link>
              <Link href="/report">
                <Button 
                  variant={location === '/report' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-report"
                >
                  {t.nav.report}
                </Button>
              </Link>
              <Link href="/goals">
                <Button 
                  variant={location === '/goals' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-goals"
                >
                  {t.nav.goals}
                </Button>
              </Link>
              <Link href="/profile">
                <Button 
                  variant={location === '/profile' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-profile"
                >
                  {t.nav.profile}
                </Button>
              </Link>
              <Link href="/education">
                <Button 
                  variant={location === '/education' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-education"
                >
                  {t.nav.education}
                </Button>
              </Link>
              <Link href="/friends">
                <Button 
                  variant={location === '/friends' ? 'secondary' : 'ghost'} 
                  size="sm"
                  data-testid="link-friends"
                >
                  {t.nav.friends}
                </Button>
              </Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" data-testid="button-language">
                <Globe className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {(Object.keys(languageNames) as Language[]).map((lang) => (
                <DropdownMenuItem
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className={language === lang ? 'bg-accent' : ''}
                  data-testid={`menu-language-${lang}`}
                >
                  {languageNames[lang]}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
            data-testid="button-theme"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>

          {user ? (
            <>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleLogout}
                className="hidden md:flex"
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                data-testid="button-mobile-menu"
              >
                {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </Button>
            </>
          ) : (
            <div className="hidden md:flex items-center gap-2">
              <Link href="/login">
                <Button variant="ghost" size="sm" data-testid="link-login">
                  {t.nav.login}
                </Button>
              </Link>
              <Link href="/signup">
                <Button variant="default" size="sm" data-testid="link-register">
                  {t.nav.register}
                </Button>
              </Link>
            </div>
          )}

          {!user && (
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu-guest"
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-background/95 backdrop-blur-md border-b border-border">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-2">
            {user ? (
              <>
                <Link href="/dashboard" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start" data-testid="mobile-link-dashboard">
                    {t.nav.dashboard}
                  </Button>
                </Link>
                <Link href="/report" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start" data-testid="mobile-link-report">
                    {t.nav.report}
                  </Button>
                </Link>
                <Link href="/goals" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start" data-testid="mobile-link-goals">
                    {t.nav.goals}
                  </Button>
                </Link>
                <Link href="/profile" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start" data-testid="mobile-link-profile">
                    {t.nav.profile}
                  </Button>
                </Link>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-destructive" 
                  onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
                  data-testid="mobile-button-logout"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  {t.nav.logout}
                </Button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start" data-testid="mobile-link-login">
                    {t.nav.login}
                  </Button>
                </Link>
                <Link href="/signup" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="default" className="w-full" data-testid="mobile-link-register">
                    {t.nav.register}
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
