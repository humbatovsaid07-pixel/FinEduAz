import az from './az.json';
import en from './en.json';
import ru from './ru.json';

export type Language = 'az' | 'en' | 'ru';

export const translations = {
  az,
  en,
  ru
} as const;

export type TranslationKeys = typeof az;

export function getTranslation(lang: Language): TranslationKeys {
  return translations[lang];
}

export const languageNames: Record<Language, string> = {
  az: 'Azərbaycan',
  en: 'English',
  ru: 'Русский'
};
