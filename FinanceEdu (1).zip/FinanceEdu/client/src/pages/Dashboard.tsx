import { Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { TrendingUp, TrendingDown, Target, ArrowRight, Plus, Minus, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { TransactionTable } from '@/components/TransactionTable';
import { TransactionForm } from '@/components/TransactionForm';
import { FinnyAdvisor } from '@/components/FinnyAdvisor';
import { GoalCard } from '@/components/GoalCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { Transaction, Goal, FinnyAdvice } from '@shared/schema';

export default function Dashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  const { data: goals = [], isLoading: goalsLoading } = useQuery<Goal[]>({
    queryKey: ['/api/goals'],
  });

  const { data: finnyAdvice = [] } = useQuery<FinnyAdvice[]>({
    queryKey: ['/api/finny'],
  });

  const addTransactionMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/transactions', {
        ...data,
        date: data.date.toISOString(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/finny'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const editTransactionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Transaction> }) => {
      const res = await apiRequest('PATCH', `/api/transactions/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/finny'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const deleteTransactionMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/finny'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const addGoalSavingsMutation = useMutation({
    mutationFn: async ({ goalId, amount }: { goalId: string; amount: number }) => {
      const res = await apiRequest('POST', `/api/goals/${goalId}/savings`, { amount });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const deleteGoalMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/goals/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthlyTransactions = transactions.filter((t) => {
    const date = new Date(t.date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  const monthlyIncome = monthlyTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const monthlyExpense = monthlyTransactions
    .filter((t) => t.type === 'outcome')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalGoalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0);
  const totalGoalCurrent = goals.reduce((sum, g) => sum + g.currentAmount, 0);
  const goalProgress = totalGoalTarget > 0 ? (totalGoalCurrent / totalGoalTarget) * 100 : 0;

  const sortedTransactions = [...transactions].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  if (transactionsLoading || goalsLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-10 w-64" />
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
          <div className="grid gap-6 lg:grid-cols-3">
            <Skeleton className="h-[400px] lg:col-span-2" />
            <Skeleton className="h-[400px]" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">
              {t.dashboard.greeting}, {user?.fullName?.split(' ')[0]}!
            </h1>
            <p className="text-muted-foreground">{t.app.subtitle}</p>
          </div>
          <div className="flex gap-2">
            <TransactionForm
              onSubmit={async (data) => {
                await addTransactionMutation.mutateAsync(data);
              }}
              defaultType="income"
              trigger={
                <Button variant="outline" data-testid="button-add-income">
                  <Plus className="mr-2 h-4 w-4" />
                  {t.dashboard.addIncome}
                </Button>
              }
            />
            <TransactionForm
              onSubmit={async (data) => {
                await addTransactionMutation.mutateAsync(data);
              }}
              defaultType="outcome"
              trigger={
                <Button data-testid="button-add-expense">
                  <Minus className="mr-2 h-4 w-4" />
                  {t.dashboard.addExpense}
                </Button>
              }
            />
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card data-testid="card-monthly-expense">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.dashboard.monthlyExpense}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-red-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                {monthlyExpense.toFixed(2)} AZN
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-monthly-income">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.dashboard.monthlyIncome}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {monthlyIncome.toFixed(2)} AZN
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-goal-progress">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.dashboard.goalProgress}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Target className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{goalProgress.toFixed(0)}%</div>
              <Progress value={goalProgress} className="h-2 mt-2" />
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <TransactionTable
              transactions={sortedTransactions}
              onEdit={async (id, data) => {
                await editTransactionMutation.mutateAsync({ id, data });
              }}
              onDelete={async (id) => {
                await deleteTransactionMutation.mutateAsync(id);
              }}
            />
          </div>

          <div className="space-y-6">
            <Card className="hover-elevate active-elevate-2 cursor-pointer" data-testid="card-report-link">
              <Link href="/report">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center justify-between">
                    {t.dashboard.viewReport}
                    <ArrowRight className="h-4 w-4" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{t.report.title}</p>
                </CardContent>
              </Link>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center justify-between gap-2">
                  {t.dashboard.recentGoals}
                  <Link href="/goals">
                    <Button variant="ghost" size="icon" className="h-8 w-8" data-testid="link-goals-page">
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {goals.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    {t.goals.noGoals}
                  </p>
                ) : (
                  goals.slice(0, 3).map((goal) => (
                    <GoalCard
                      key={goal.id}
                      goal={goal}
                      compact
                      onAddSavings={async (goalId, amount) => {
                        await addGoalSavingsMutation.mutateAsync({ goalId, amount });
                      }}
                      onDelete={async (id) => {
                        await deleteGoalMutation.mutateAsync(id);
                      }}
                    />
                  ))
                )}
              </CardContent>
            </Card>

            <FinnyAdvisor advice={finnyAdvice} compact />
          </div>
        </div>
      </div>
    </div>
  );
}
