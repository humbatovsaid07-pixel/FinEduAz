import { useLanguage } from "@/contexts/LanguageContext";
import { Card } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { BookOpen } from "lucide-react";

export default function Education() {
  const { language, t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-background/95 p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <BookOpen className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold text-foreground">{t.education.title}</h1>
        </div>

        <Card className="p-6 md:p-8 border border-primary/10">
          <Accordion type="single" collapsible className="w-full space-y-4">
            <AccordionItem value="credit" className="border-none">
              <AccordionTrigger className="hover:text-primary text-lg font-semibold py-4">
                {t.education.creditTitle}
              </AccordionTrigger>
              <AccordionContent className="text-foreground/80 leading-relaxed whitespace-pre-wrap pb-4">
                {t.education.creditContent}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="mortgage" className="border-none">
              <AccordionTrigger className="hover:text-primary text-lg font-semibold py-4">
                {t.education.mortgageTitle}
              </AccordionTrigger>
              <AccordionContent className="text-foreground/80 leading-relaxed whitespace-pre-wrap pb-4">
                {t.education.mortgageContent}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="fraud" className="border-none">
              <AccordionTrigger className="hover:text-primary text-lg font-semibold py-4">
                {t.education.fraudTitle}
              </AccordionTrigger>
              <AccordionContent className="text-foreground/80 leading-relaxed whitespace-pre-wrap pb-4">
                {t.education.fraudContent}
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </Card>
      </div>
    </div>
  );
}
