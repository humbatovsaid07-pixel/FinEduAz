import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Users, Trophy } from "lucide-react";

export default function Friends() {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const [email, setEmail] = useState("");

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-background/95 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Users className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold text-foreground">{t.friends.title}</h1>
        </div>

        <Tabs defaultValue="leaderboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="leaderboard" className="text-xs md:text-sm">{t.friends.savingRace}</TabsTrigger>
            <TabsTrigger value="add" className="text-xs md:text-sm">{t.friends.addFriend}</TabsTrigger>
            <TabsTrigger value="requests" className="text-xs md:text-sm">{t.friends.incomingRequests}</TabsTrigger>
            <TabsTrigger value="friends" className="text-xs md:text-sm">{t.friends.friendsList}</TabsTrigger>
          </TabsList>

          <TabsContent value="leaderboard" className="space-y-4">
            <Card className="p-6 border border-primary/10">
              <div className="flex items-center gap-2 mb-4">
                <Trophy className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-semibold">{t.friends.leaderboard}</h2>
              </div>

              <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                <p className="text-sm text-foreground/60">{t.friends.savingPercentage}</p>
                <p className="text-2xl font-bold text-primary">24.5%</p>
                <p className="text-xs text-foreground/50 mt-2">{t.friends.betterThanLastMonth}</p>
              </div>

              <div className="space-y-3 mt-6">
                <p className="text-foreground/50 text-center py-8">{t.friends.noFriends}</p>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="add" className="space-y-4">
            <Card className="p-6 border border-primary/10">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">{t.friends.email}</label>
                  <Input
                    type="email"
                    placeholder="friend@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    data-testid="input-friend-email"
                  />
                </div>
                <Button
                  disabled={!email}
                  className="w-full"
                  data-testid="button-send-friend-request"
                >
                  {t.friends.sendRequest}
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="requests" className="space-y-4">
            <Card className="p-6 border border-primary/10">
              <p className="text-foreground/50 text-center py-8">{t.friends.noPending}</p>
            </Card>
          </TabsContent>

          <TabsContent value="friends" className="space-y-4">
            <Card className="p-6 border border-primary/10">
              <p className="text-foreground/50 text-center py-8">{t.friends.noFriends}</p>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
