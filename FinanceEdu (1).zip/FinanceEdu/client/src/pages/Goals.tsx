import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Plus, Target, Loader2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Skeleton } from '@/components/ui/skeleton';
import { GoalCard } from '@/components/GoalCard';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { Goal } from '@shared/schema';

const goalFormSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  targetAmount: z.coerce.number().positive('Target must be positive'),
});

type GoalFormData = z.infer<typeof goalFormSchema>;

export default function Goals() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const { data: goals = [], isLoading } = useQuery<Goal[]>({
    queryKey: ['/api/goals'],
  });

  const form = useForm<GoalFormData>({
    resolver: zodResolver(goalFormSchema),
    defaultValues: {
      title: '',
      targetAmount: 0,
    },
  });

  const createGoalMutation = useMutation({
    mutationFn: async (data: GoalFormData) => {
      const res = await apiRequest('POST', '/api/goals', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({ title: t.common.success });
      setIsOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const addSavingsMutation = useMutation({
    mutationFn: async ({ goalId, amount }: { goalId: string; amount: number }) => {
      const res = await apiRequest('POST', `/api/goals/${goalId}/savings`, { amount });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const deleteGoalMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/goals/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({ title: t.common.success });
    },
    onError: () => {
      toast({ title: t.common.error, variant: 'destructive' });
    },
  });

  const handleSubmit = async (data: GoalFormData) => {
    await createGoalMutation.mutateAsync(data);
  };

  const completedGoals = goals.filter((g) => g.currentAmount >= g.targetAmount);
  const activeGoals = goals.filter((g) => g.currentAmount < g.targetAmount);

  const totalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0);
  const totalCurrent = goals.reduce((sum, g) => sum + g.currentAmount, 0);
  const overallProgress = totalTarget > 0 ? (totalCurrent / totalTarget) * 100 : 0;

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-32" />
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Skeleton className="h-48" />
            <Skeleton className="h-48" />
            <Skeleton className="h-48" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">{t.goals.title}</h1>
            <p className="text-muted-foreground">
              {goals.length} {t.goals.title.toLowerCase()} | {completedGoals.length} {t.goals.completed.toLowerCase()}
            </p>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-new-goal">
                <Plus className="mr-2 h-4 w-4" />
                {t.goals.addGoal}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>{t.goals.addGoal}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.goals.goalTitle}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t.goals.goalTitle}
                            {...field}
                            data-testid="input-goal-title"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="targetAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t.goals.targetAmount} (AZN)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            min="0"
                            placeholder="0.00"
                            {...field}
                            data-testid="input-goal-target"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex gap-2 justify-end">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsOpen(false)}
                      data-testid="button-cancel-goal"
                    >
                      {t.transactions.cancel}
                    </Button>
                    <Button
                      type="submit"
                      disabled={createGoalMutation.isPending}
                      data-testid="button-save-goal"
                    >
                      {createGoalMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {t.common.loading}
                        </>
                      ) : (
                        t.transactions.save
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {goals.length > 0 && (
          <Card className="bg-gradient-to-br from-primary/10 to-accent/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">{t.goals.progress}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl font-bold">{overallProgress.toFixed(0)}%</span>
                <span className="text-muted-foreground">
                  {totalCurrent.toFixed(2)} / {totalTarget.toFixed(2)} AZN
                </span>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
                  style={{ width: `${Math.min(overallProgress, 100)}%` }}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {goals.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <Target className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{t.goals.noGoals}</h3>
              <p className="text-muted-foreground text-center mb-4 max-w-sm">
                {t.app.subtitle}
              </p>
              <Button onClick={() => setIsOpen(true)} data-testid="button-create-first-goal">
                <Plus className="mr-2 h-4 w-4" />
                {t.goals.addGoal}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {activeGoals.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4">{t.goals.title}</h2>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {activeGoals.map((goal) => (
                    <GoalCard
                      key={goal.id}
                      goal={goal}
                      onAddSavings={async (goalId, amount) => {
                        await addSavingsMutation.mutateAsync({ goalId, amount });
                      }}
                      onDelete={async (id) => {
                        await deleteGoalMutation.mutateAsync(id);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {completedGoals.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4">{t.goals.completed}</h2>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {completedGoals.map((goal) => (
                    <GoalCard
                      key={goal.id}
                      goal={goal}
                      onAddSavings={async () => {}}
                      onDelete={async (id) => {
                        await deleteGoalMutation.mutateAsync(id);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
