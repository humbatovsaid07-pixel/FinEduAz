import { useQuery } from '@tanstack/react-query';
import { TrendingUp, TrendingDown, Wallet, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { FinnyAdvisor } from '@/components/FinnyAdvisor';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import type { Transaction, RegionalAverage, FinnyAdvice } from '@shared/schema';

export default function Report() {
  const { t } = useLanguage();
  const { user } = useAuth();

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  const { data: averages = [], isLoading: averagesLoading } = useQuery<RegionalAverage[]>({
    queryKey: ['/api/averages'],
  });

  const { data: finnyAdvice = [] } = useQuery<FinnyAdvice[]>({
    queryKey: ['/api/finny'],
  });

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthlyTransactions = transactions.filter((trans) => {
    const date = new Date(trans.date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  const totalIncome = monthlyTransactions
    .filter((trans) => trans.type === 'income')
    .reduce((sum, trans) => sum + trans.amount, 0);

  const totalOutcome = monthlyTransactions
    .filter((trans) => trans.type === 'outcome')
    .reduce((sum, trans) => sum + trans.amount, 0);

  const totalSavings = totalIncome - totalOutcome;

  const categoryBreakdown = monthlyTransactions
    .filter((trans) => trans.type === 'outcome')
    .reduce((acc, trans) => {
      acc[trans.category] = (acc[trans.category] || 0) + trans.amount;
      return acc;
    }, {} as Record<string, number>);

  const categoryLabels: Record<string, string> = {
    food: t.transactions.categories.food,
    transport: t.transactions.categories.transport,
    entertainment: t.transactions.categories.entertainment,
    education: t.transactions.categories.education,
    health: t.transactions.categories.health,
    shopping: t.transactions.categories.shopping,
    utilities: t.transactions.categories.utilities,
    other: t.transactions.categories.other,
  };

  const categoryColors: Record<string, string> = {
    food: 'bg-orange-500',
    transport: 'bg-blue-500',
    entertainment: 'bg-purple-500',
    education: 'bg-green-500',
    health: 'bg-red-500',
    shopping: 'bg-pink-500',
    utilities: 'bg-yellow-500',
    other: 'bg-gray-500',
  };

  const getAgeGroup = (age: number): string => {
    if (age >= 14 && age <= 18) return '14-18';
    if (age >= 19 && age <= 25) return '19-25';
    if (age >= 26 && age <= 35) return '26-35';
    return '35+';
  };

  const userAgeGroup = user?.age ? getAgeGroup(user.age) : '19-25';
  const userRegion = user?.region || 'Bakı';

  const regionalAverage = averages.find(
    (avg) => avg.region === userRegion && avg.ageGroup === userAgeGroup
  );

  const averageExpense = regionalAverage?.averageExpense || 0;
  const difference = totalOutcome - averageExpense;
  const percentDiff = averageExpense > 0 ? ((difference / averageExpense) * 100) : 0;

  if (transactionsLoading || averagesLoading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
        <div className="max-w-5xl mx-auto space-y-6">
          <Skeleton className="h-10 w-64" />
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
          <Skeleton className="h-[300px]" />
          <Skeleton className="h-[200px]" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] p-4 md:p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">{t.report.title}</h1>
          <p className="text-muted-foreground">
            {new Date().toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card data-testid="card-total-income">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.report.totalIncome}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-green-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {totalIncome.toFixed(2)} AZN
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-total-outcome">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.report.totalOutcome}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-red-500" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                {totalOutcome.toFixed(2)} AZN
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-total-savings">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {t.report.totalSavings}
              </CardTitle>
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Wallet className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${totalSavings >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                {totalSavings.toFixed(2)} AZN
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>{t.report.comparison}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{t.report.yourSpending}</p>
                    <p className="text-xl font-bold">{totalOutcome.toFixed(2)} AZN</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">
                      {userRegion} ({userAgeGroup})
                    </p>
                    <p className="text-xl font-bold text-muted-foreground">
                      {averageExpense.toFixed(2)} AZN
                    </p>
                  </div>
                </div>

                <div className="relative">
                  <Progress 
                    value={Math.min((totalOutcome / (averageExpense * 2)) * 100, 100)} 
                    className="h-4"
                  />
                  <div 
                    className="absolute top-0 h-4 w-0.5 bg-foreground"
                    style={{ left: '50%' }}
                  />
                </div>

                <div className={`flex items-center gap-2 p-3 rounded-lg ${
                  difference <= 0 
                    ? 'bg-green-500/10 text-green-600 dark:text-green-400' 
                    : 'bg-red-500/10 text-red-600 dark:text-red-400'
                }`}>
                  {difference <= 0 ? (
                    <ArrowDown className="h-5 w-5" />
                  ) : (
                    <ArrowUp className="h-5 w-5" />
                  )}
                  <span className="text-sm font-medium">
                    {Math.abs(difference).toFixed(2)} AZN {difference <= 0 ? t.report.betterThan : t.report.worseThan}
                  </span>
                  <Badge variant="outline" className="ml-auto">
                    {percentDiff > 0 ? '+' : ''}{percentDiff.toFixed(0)}%
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t.transactions.category}</CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(categoryBreakdown).length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  {t.dashboard.noTransactions}
                </p>
              ) : (
                <div className="space-y-4">
                  {Object.entries(categoryBreakdown)
                    .sort((a, b) => b[1] - a[1])
                    .map(([category, amount]) => {
                      const percentage = totalOutcome > 0 ? (amount / totalOutcome) * 100 : 0;
                      return (
                        <div key={category} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <div className={`w-3 h-3 rounded-full ${categoryColors[category]}`} />
                              <span>{categoryLabels[category]}</span>
                            </div>
                            <span className="font-medium">{amount.toFixed(2)} AZN</span>
                          </div>
                          <Progress value={percentage} className="h-2" />
                        </div>
                      );
                    })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t.report.finnyTitle}</CardTitle>
          </CardHeader>
          <CardContent>
            <FinnyAdvisor advice={finnyAdvice} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
