import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import MemoryStore from "memorystore";
import { storage } from "./storage";
import { insertUserSchema, insertTransactionSchema, insertGoalSchema, loginSchema, transactionCategories } from "@shared/schema";
import type { User, Transaction, FinnyAdvice } from "@shared/schema";

declare module "express-session" {
  interface SessionData {
    userId: string;
  }
}

const SessionStore = MemoryStore(session);

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (!req.session || !req.session.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

function generateFinnyAdvice(transactions: Transaction[], user: User, regionalAverages: any[]): FinnyAdvice[] {
  const advice: FinnyAdvice[] = [];
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthlyTransactions = transactions.filter((t) => {
    const date = new Date(t.date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  const totalIncome = monthlyTransactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalOutcome = monthlyTransactions
    .filter((t) => t.type === "outcome")
    .reduce((sum, t) => sum + t.amount, 0);

  const savings = totalIncome - totalOutcome;

  const categoryTotals: Record<string, number> = {};
  monthlyTransactions
    .filter((t) => t.type === "outcome")
    .forEach((t) => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    });

  const getAgeGroup = (age: number): string => {
    if (age >= 14 && age <= 18) return "14-18";
    if (age >= 19 && age <= 25) return "19-25";
    if (age >= 26 && age <= 35) return "26-35";
    return "35+";
  };

  const userAgeGroup = getAgeGroup(user.age);
  const regionalAverage = regionalAverages.find(
    (avg) => avg.region === user.region && avg.ageGroup === userAgeGroup
  );

  if (regionalAverage) {
    const avgExpense = regionalAverage.averageExpense;
    if (totalOutcome > avgExpense * 1.2) {
      advice.push({
        id: "above-average",
        type: "warning",
        message: `Bu ay ${user.region} ${userAgeGroup} yaş qrupunun ortalamasından ${(totalOutcome - avgExpense).toFixed(0)} AZN daha çox xərc etmisiniz.`,
      });
    } else if (totalOutcome < avgExpense * 0.8) {
      advice.push({
        id: "below-average",
        type: "success",
        message: `Əla! Bu ay ${user.region} ${userAgeGroup} yaş qrupundan ${(avgExpense - totalOutcome).toFixed(0)} AZN daha az xərcləmisiniz.`,
      });
    }
  }

  if (categoryTotals["entertainment"] && totalOutcome > 0) {
    const entertainmentPercent = (categoryTotals["entertainment"] / totalOutcome) * 100;
    if (entertainmentPercent > 30) {
      advice.push({
        id: "high-entertainment",
        type: "warning",
        message: "Bu ay əyləncə xərcləriniz yüksəkdir. Növbəti ay 10% azaltmağı tövsiyə edirəm.",
        category: "entertainment",
      });
    }
  }

  if (categoryTotals["food"] && totalOutcome > 0) {
    const foodPercent = (categoryTotals["food"] / totalOutcome) * 100;
    if (foodPercent >= 20 && foodPercent <= 40) {
      advice.push({
        id: "balanced-food",
        type: "success",
        message: "Qida xərcləriniz çox balanslıdır.",
        category: "food",
      });
    }
  }

  if (categoryTotals["transport"] && totalOutcome > 0) {
    const transportPercent = (categoryTotals["transport"] / totalOutcome) * 100;
    if (transportPercent > 25) {
      advice.push({
        id: "high-transport",
        type: "tip",
        message: "Nəqliyyat xərclərinizi azaltmağa çalışın.",
        category: "transport",
      });
    }
  }

  if (savings > 0) {
    advice.push({
      id: "positive-savings",
      type: "success",
      message: `Bu ay ${savings.toFixed(0)} AZN qənaət etmisiniz. Əla nəticə!`,
    });
  } else if (savings < 0) {
    advice.push({
      id: "negative-savings",
      type: "warning",
      message: "Bu ay qənaət etməmisiniz. Gəlirlərinizi artırmağa və ya xərcləri azaltmağa çalışın.",
    });
  }

  if (advice.length === 0) {
    advice.push({
      id: "general-tip",
      type: "info",
      message: "Xərclərinizi izləməyə davam edin. Məqsədlərinizə çatmaq üçün düzgün yoldasınız!",
    });
  }

  return advice;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use(
    session({
      store: new SessionStore({
        checkPeriod: 86400000,
      }),
      secret: process.env.SESSION_SECRET || "finedu-secret-key-2024",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000,
      },
    })
  );

  app.get("/api/keepalive", (req, res) => {
    res.json({ status: "alive", timestamp: new Date().toISOString() });
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const parsed = insertUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid data", details: parsed.error.errors });
      }

      const existing = await storage.getUserByFullName(parsed.data.fullName);
      if (existing) {
        return res.status(409).json({ error: "User already exists" });
      }

      const user = await storage.createUser(parsed.data);
      req.session.userId = user.id;
      
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid data" });
      }

      const user = await storage.validatePassword(parsed.data.fullName, parsed.data.password);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json(null);
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json(null);
    }

    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  app.patch("/api/users/me", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { fullName, age, region, language, theme } = req.body;
      
      const updated = await storage.updateUser(userId, { fullName, age, region, language, theme });
      if (!updated) {
        return res.status(404).json({ error: "User not found" });
      }

      const { password, ...userWithoutPassword } = updated;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Get transactions error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/transactions", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const data = { ...req.body, userId };
      
      const parsed = insertTransactionSchema.safeParse(data);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid data", details: parsed.error.errors });
      }

      const transaction = await storage.createTransaction(parsed.data);
      res.status(201).json(transaction);
    } catch (error) {
      console.error("Create transaction error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.session.userId!;
      
      const existing = await storage.getTransaction(id);
      if (!existing || existing.userId !== userId) {
        return res.status(404).json({ error: "Transaction not found" });
      }

      const updated = await storage.updateTransaction(id, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Update transaction error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.session.userId!;
      
      const existing = await storage.getTransaction(id);
      if (!existing || existing.userId !== userId) {
        return res.status(404).json({ error: "Transaction not found" });
      }

      await storage.deleteTransaction(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete transaction error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/goals", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const goals = await storage.getGoals(userId);
      res.json(goals);
    } catch (error) {
      console.error("Get goals error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/goals", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const data = { ...req.body, userId };
      
      const parsed = insertGoalSchema.safeParse(data);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid data", details: parsed.error.errors });
      }

      const goal = await storage.createGoal(parsed.data);
      res.status(201).json(goal);
    } catch (error) {
      console.error("Create goal error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/goals/:id/savings", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.session.userId!;
      const { amount } = req.body;
      
      const existing = await storage.getGoal(id);
      if (!existing || existing.userId !== userId) {
        return res.status(404).json({ error: "Goal not found" });
      }

      const updated = await storage.addSavingsToGoal(id, amount);
      res.json(updated);
    } catch (error) {
      console.error("Add savings error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/goals/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.session.userId!;
      
      const existing = await storage.getGoal(id);
      if (!existing || existing.userId !== userId) {
        return res.status(404).json({ error: "Goal not found" });
      }

      await storage.deleteGoal(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete goal error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/averages", async (req, res) => {
    try {
      const averages = await storage.getRegionalAverages();
      res.json(averages);
    } catch (error) {
      console.error("Get averages error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/finny", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const transactions = await storage.getTransactions(userId);
      const averages = await storage.getRegionalAverages();
      
      const advice = generateFinnyAdvice(transactions, user, averages);
      res.json(advice);
    } catch (error) {
      console.error("Get finny advice error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/friends/requests", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const requests = await storage.getFriendRequests(userId);
      res.json(requests);
    } catch (error) {
      console.error("Get friend requests error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/friends/requests", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { email } = req.body;

      const toUser = await storage.getUserByFullName(email);
      if (!toUser) {
        return res.status(404).json({ error: "User not found" });
      }

      const request = await storage.sendFriendRequest({
        fromUserId: userId,
        toUserId: toUser.id,
        status: "pending",
      });

      res.status(201).json(request);
    } catch (error) {
      console.error("Send friend request error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/friends/requests/:requestId", requireAuth, async (req, res) => {
    try {
      const { requestId } = req.params;
      const { status } = req.body;

      if (status !== "accepted" && status !== "rejected") {
        return res.status(400).json({ error: "Invalid status" });
      }

      const updated = await storage.respondToFriendRequest(requestId, status);
      if (!updated) {
        return res.status(404).json({ error: "Request not found" });
      }

      res.json(updated);
    } catch (error) {
      console.error("Respond to friend request error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/friends/requests/:requestId", requireAuth, async (req, res) => {
    try {
      const { requestId } = req.params;
      const success = await storage.cancelFriendRequest(requestId);
      
      if (!success) {
        return res.status(404).json({ error: "Request not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Cancel friend request error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/friends", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const friends = await storage.getFriends(userId);
      const safeFriends = friends.map(({ password, ...friend }) => friend);
      res.json(safeFriends);
    } catch (error) {
      console.error("Get friends error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/friends/:friendId", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { friendId } = req.params;
      
      const success = await storage.removeFriend(userId, friendId);
      if (!success) {
        return res.status(404).json({ error: "Friend not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Remove friend error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/saving-race", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      let race = await storage.getSavingRace(userId);
      
      if (!race) {
        race = await storage.updateSavingRace(userId, {
          currentMonthSavings: 0,
          previousMonthSavings: 0,
          savingPercentage: 0,
          lastUpdated: new Date().toISOString(),
        });
      }

      res.json(race);
    } catch (error) {
      console.error("Get saving race error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/saving-race", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const updated = await storage.updateSavingRace(userId, req.body);
      res.json(updated);
    } catch (error) {
      console.error("Update saving race error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/leaderboard", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const friends = await storage.getFriends(userId);
      const friendIds = [userId, ...friends.map((f) => f.id)];
      const leaderboard = await storage.getLeaderboard(friendIds);
      res.json(leaderboard);
    } catch (error) {
      console.error("Get leaderboard error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  return httpServer;
}
