import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import type { User, InsertUser, Transaction, InsertTransaction, Goal, InsertGoal, RegionalAverage, FriendRequest, InsertFriendRequest, SavingRace } from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByFullName(fullName: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  validatePassword(fullName: string, password: string): Promise<User | null>;
  
  getTransactions(userId: string): Promise<Transaction[]>;
  getTransaction(id: string): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, data: Partial<Transaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: string): Promise<boolean>;
  
  getGoals(userId: string): Promise<Goal[]>;
  getGoal(id: string): Promise<Goal | undefined>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: string, data: Partial<Goal>): Promise<Goal | undefined>;
  deleteGoal(id: string): Promise<boolean>;
  addSavingsToGoal(goalId: string, amount: number): Promise<Goal | undefined>;
  
  getRegionalAverages(): Promise<RegionalAverage[]>;

  getFriendRequests(userId: string): Promise<{ sent: FriendRequest[]; received: FriendRequest[] }>;
  sendFriendRequest(request: InsertFriendRequest): Promise<FriendRequest>;
  respondToFriendRequest(requestId: string, status: "accepted" | "rejected"): Promise<FriendRequest | undefined>;
  cancelFriendRequest(requestId: string): Promise<boolean>;
  getFriends(userId: string): Promise<User[]>;
  removeFriend(userId: string, friendId: string): Promise<boolean>;

  getSavingRace(userId: string): Promise<SavingRace | undefined>;
  updateSavingRace(userId: string, data: Partial<SavingRace>): Promise<SavingRace>;
  getLeaderboard(userIds: string[]): Promise<SavingRace[]>;
}

const regionalAveragesData: RegionalAverage[] = [
  { region: "Bakı", ageGroup: "14-18", averageExpense: 23 },
  { region: "Bakı", ageGroup: "19-25", averageExpense: 222 },
  { region: "Bakı", ageGroup: "26-35", averageExpense: 2560 },
  { region: "Bakı", ageGroup: "35+", averageExpense: 2800 },
  { region: "Gəncə", ageGroup: "14-18", averageExpense: 21 },
  { region: "Gəncə", ageGroup: "19-25", averageExpense: 208 },
  { region: "Gəncə", ageGroup: "26-35", averageExpense: 2250 },
  { region: "Gəncə", ageGroup: "35+", averageExpense: 2400 },
  { region: "Şəki", ageGroup: "14-18", averageExpense: 24 },
  { region: "Şəki", ageGroup: "19-25", averageExpense: 205 },
  { region: "Şəki", ageGroup: "26-35", averageExpense: 2100 },
  { region: "Şəki", ageGroup: "35+", averageExpense: 2300 },
  { region: "Mingəçevir", ageGroup: "14-18", averageExpense: 22 },
  { region: "Mingəçevir", ageGroup: "19-25", averageExpense: 196 },
  { region: "Mingəçevir", ageGroup: "26-35", averageExpense: 1900 },
  { region: "Mingəçevir", ageGroup: "35+", averageExpense: 2100 },
  { region: "Sumqayıt", ageGroup: "14-18", averageExpense: 23 },
  { region: "Sumqayıt", ageGroup: "19-25", averageExpense: 210 },
  { region: "Sumqayıt", ageGroup: "26-35", averageExpense: 2000 },
  { region: "Sumqayıt", ageGroup: "35+", averageExpense: 2200 },
  { region: "Quba", ageGroup: "14-18", averageExpense: 22 },
  { region: "Quba", ageGroup: "19-25", averageExpense: 200 },
  { region: "Quba", ageGroup: "26-35", averageExpense: 2100 },
  { region: "Quba", ageGroup: "35+", averageExpense: 2300 },
  { region: "Lənkəran", ageGroup: "14-18", averageExpense: 20 },
  { region: "Lənkəran", ageGroup: "19-25", averageExpense: 217 },
  { region: "Lənkəran", ageGroup: "26-35", averageExpense: 2400 },
  { region: "Lənkəran", ageGroup: "35+", averageExpense: 2600 },
  { region: "Şəmkir", ageGroup: "14-18", averageExpense: 22 },
  { region: "Şəmkir", ageGroup: "19-25", averageExpense: 210 },
  { region: "Şəmkir", ageGroup: "26-35", averageExpense: 1800 },
  { region: "Şəmkir", ageGroup: "35+", averageExpense: 2000 },
  { region: "Naftalan", ageGroup: "14-18", averageExpense: 20 },
  { region: "Naftalan", ageGroup: "19-25", averageExpense: 205 },
  { region: "Naftalan", ageGroup: "26-35", averageExpense: 1700 },
  { region: "Naftalan", ageGroup: "35+", averageExpense: 1900 },
  { region: "Zaqatala", ageGroup: "14-18", averageExpense: 20 },
  { region: "Zaqatala", ageGroup: "19-25", averageExpense: 198 },
  { region: "Zaqatala", ageGroup: "26-35", averageExpense: 2100 },
  { region: "Zaqatala", ageGroup: "35+", averageExpense: 2300 },
];

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private transactions: Map<string, Transaction>;
  private goals: Map<string, Goal>;
  private friendRequests: Map<string, FriendRequest>;
  private savingRaces: Map<string, SavingRace>;

  constructor() {
    this.users = new Map();
    this.transactions = new Map();
    this.goals = new Map();
    this.friendRequests = new Map();
    this.savingRaces = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByFullName(fullName: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.fullName.toLowerCase() === fullName.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = {
      ...insertUser,
      id,
      password: hashedPassword,
      language: "az",
      theme: "light",
      createdAt: new Date().toISOString(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updated = { ...user, ...data };
    this.users.set(id, updated);
    return updated;
  }

  async validatePassword(fullName: string, password: string): Promise<User | null> {
    const user = await this.getUserByFullName(fullName);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getTransactions(userId: string): Promise<Transaction[]> {
    if (!userId) {
      throw new Error("User ID is required");
    }
    return Array.from(this.transactions.values())
      .filter((t) => t.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getTransaction(id: string): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    if (!insertTransaction.userId) {
      throw new Error("User ID is required");
    }
    const id = randomUUID();
    const transaction: Transaction = { ...insertTransaction, id };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransaction(id: string, data: Partial<Transaction>): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;
    
    const updated = { ...transaction, ...data };
    this.transactions.set(id, updated);
    return updated;
  }

  async deleteTransaction(id: string): Promise<boolean> {
    return this.transactions.delete(id);
  }

  async getGoals(userId: string): Promise<Goal[]> {
    if (!userId) {
      throw new Error("User ID is required");
    }
    return Array.from(this.goals.values())
      .filter((g) => g.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getGoal(id: string): Promise<Goal | undefined> {
    return this.goals.get(id);
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    if (!insertGoal.userId) {
      throw new Error("User ID is required");
    }
    const id = randomUUID();
    const goal: Goal = {
      ...insertGoal,
      id,
      currentAmount: 0,
      createdAt: new Date().toISOString(),
    };
    this.goals.set(id, goal);
    return goal;
  }

  async updateGoal(id: string, data: Partial<Goal>): Promise<Goal | undefined> {
    const goal = this.goals.get(id);
    if (!goal) return undefined;
    
    const updated = { ...goal, ...data };
    this.goals.set(id, updated);
    return updated;
  }

  async deleteGoal(id: string): Promise<boolean> {
    return this.goals.delete(id);
  }

  async addSavingsToGoal(goalId: string, amount: number): Promise<Goal | undefined> {
    const goal = this.goals.get(goalId);
    if (!goal) return undefined;
    
    const updated = { ...goal, currentAmount: goal.currentAmount + amount };
    this.goals.set(goalId, updated);
    return updated;
  }

  async getRegionalAverages(): Promise<RegionalAverage[]> {
    return regionalAveragesData;
  }

  async getFriendRequests(userId: string): Promise<{ sent: FriendRequest[]; received: FriendRequest[] }> {
    const all = Array.from(this.friendRequests.values());
    return {
      sent: all.filter((r) => r.fromUserId === userId),
      received: all.filter((r) => r.toUserId === userId),
    };
  }

  async sendFriendRequest(request: InsertFriendRequest): Promise<FriendRequest> {
    const id = randomUUID();
    const friendRequest: FriendRequest = {
      ...request,
      id,
      createdAt: new Date().toISOString(),
    };
    this.friendRequests.set(id, friendRequest);
    return friendRequest;
  }

  async respondToFriendRequest(requestId: string, status: "accepted" | "rejected"): Promise<FriendRequest | undefined> {
    const request = this.friendRequests.get(requestId);
    if (!request) return undefined;

    const updated = { ...request, status };
    this.friendRequests.set(requestId, updated);
    return updated;
  }

  async cancelFriendRequest(requestId: string): Promise<boolean> {
    return this.friendRequests.delete(requestId);
  }

  async getFriends(userId: string): Promise<User[]> {
    const accepted = Array.from(this.friendRequests.values()).filter(
      (r) => (r.fromUserId === userId || r.toUserId === userId) && r.status === "accepted"
    );

    const friendIds = accepted.map((r) => (r.fromUserId === userId ? r.toUserId : r.fromUserId));
    return friendIds.map((id) => this.users.get(id)).filter((u): u is User => !!u);
  }

  async removeFriend(userId: string, friendId: string): Promise<boolean> {
    const request = Array.from(this.friendRequests.values()).find(
      (r) =>
        r.status === "accepted" &&
        ((r.fromUserId === userId && r.toUserId === friendId) ||
          (r.fromUserId === friendId && r.toUserId === userId))
    );

    if (request) {
      return this.friendRequests.delete(request.id);
    }
    return false;
  }

  async getSavingRace(userId: string): Promise<SavingRace | undefined> {
    return this.savingRaces.get(userId);
  }

  async updateSavingRace(userId: string, data: Partial<SavingRace>): Promise<SavingRace> {
    const existing = this.savingRaces.get(userId);
    const savingRace: SavingRace = {
      userId,
      currentMonthSavings: data.currentMonthSavings ?? existing?.currentMonthSavings ?? 0,
      previousMonthSavings: data.previousMonthSavings ?? existing?.previousMonthSavings ?? 0,
      savingPercentage: data.savingPercentage ?? existing?.savingPercentage ?? 0,
      lastUpdated: new Date().toISOString(),
    };
    this.savingRaces.set(userId, savingRace);
    return savingRace;
  }

  async getLeaderboard(userIds: string[]): Promise<SavingRace[]> {
    return userIds
      .map((id) => this.savingRaces.get(id))
      .filter((r): r is SavingRace => !!r)
      .sort((a, b) => b.savingPercentage - a.savingPercentage);
  }
}

export const storage = new MemStorage();
