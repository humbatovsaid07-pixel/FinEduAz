import { z } from "zod";

export const regions = [
  "Bakı",
  "Gəncə",
  "Şəki",
  "Mingəçevir",
  "Sumqayıt",
  "Quba",
  "Lənkəran",
  "Şəmkir",
  "Naftalan",
  "Zaqatala"
] as const;

export const ageGroups = ["14-18", "19-25", "26-35", "35+"] as const;

export const expenseCategories = [
  "food",
  "transport",
  "entertainment",
  "education",
  "health",
  "shopping",
  "utilities",
  "other"
] as const;

export const incomeCategories = [
  "salary",
  "gift",
  "freelance",
  "grant",
  "socialaid",
  "rental",
  "bonus"
] as const;

export const transactionCategories = [
  ...expenseCategories,
  ...incomeCategories
] as const;

export const savingMethods = ["cash", "bank", "investing"] as const;

export const userSchema = z.object({
  id: z.string(),
  fullName: z.string().min(2),
  age: z.number().min(14).max(100),
  region: z.enum(regions),
  password: z.string().min(4),
  language: z.enum(["az", "en", "ru"]).default("az"),
  theme: z.enum(["light", "dark"]).default("light"),
  createdAt: z.string()
});

export const insertUserSchema = userSchema.omit({ id: true, createdAt: true, language: true, theme: true });

export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const transactionSchema = z.object({
  id: z.string(),
  userId: z.string(),
  date: z.string(),
  category: z.enum(transactionCategories),
  amount: z.number().positive(),
  type: z.enum(["income", "outcome"]),
  description: z.string().optional()
});

export const insertTransactionSchema = transactionSchema.omit({ id: true });

export type Transaction = z.infer<typeof transactionSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export const goalSchema = z.object({
  id: z.string(),
  userId: z.string(),
  title: z.string().min(1),
  targetAmount: z.number().positive(),
  currentAmount: z.number().min(0).default(0),
  createdAt: z.string()
});

export const insertGoalSchema = goalSchema.omit({ id: true, createdAt: true, currentAmount: true });

export type Goal = z.infer<typeof goalSchema>;
export type InsertGoal = z.infer<typeof insertGoalSchema>;

export const regionalAverageSchema = z.object({
  region: z.enum(regions),
  ageGroup: z.enum(ageGroups),
  averageExpense: z.number()
});

export type RegionalAverage = z.infer<typeof regionalAverageSchema>;

export const loginSchema = z.object({
  fullName: z.string().min(2),
  password: z.string().min(4)
});

export type LoginInput = z.infer<typeof loginSchema>;

export const finnyAdviceSchema = z.object({
  id: z.string(),
  type: z.enum(["warning", "success", "tip", "info"]),
  message: z.string(),
  category: z.enum(expenseCategories).optional()
});

export type FinnyAdvice = z.infer<typeof finnyAdviceSchema>;

export const friendRequestSchema = z.object({
  id: z.string(),
  fromUserId: z.string(),
  toUserId: z.string(),
  status: z.enum(["pending", "accepted", "rejected"]),
  createdAt: z.string()
});

export type FriendRequest = z.infer<typeof friendRequestSchema>;

export const insertFriendRequestSchema = friendRequestSchema.omit({ id: true, createdAt: true });
export type InsertFriendRequest = z.infer<typeof insertFriendRequestSchema>;

export const savingRaceSchema = z.object({
  userId: z.string(),
  currentMonthSavings: z.number().default(0),
  previousMonthSavings: z.number().default(0),
  savingPercentage: z.number().default(0),
  lastUpdated: z.string()
});

export type SavingRace = z.infer<typeof savingRaceSchema>;
